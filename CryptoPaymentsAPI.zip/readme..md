# Coded by @musthang on discord :p

> Fun little crypto payment api I made a while back using cryptapi.io

`Please don't claim my code but feel free to use it for yourself!`